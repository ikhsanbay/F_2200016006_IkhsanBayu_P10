package com.mytsel.mytsel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
